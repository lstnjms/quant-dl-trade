@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul

rem === ͨ�����ã������޸ģ�===
set "CONDA_ROOT=D:\anaconda3"
set "CONDA_ENV=quant"
set "WORK_DIR=D:\QS\DL\src"
set "LOG_DIR=D:\QS\DL\logs\daily"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

rem === ʱ���������־�ļ��� ===
for /f "tokens=1 delims=." %%i in ('wmic os get localdatetime ^| find "."') do set "DTS=%%i"
set "TS=!DTS:~0,8!_!DTS:~8,6!"

set "LOG_FILE=%LOG_DIR%\06-inc_stk_nineturn-!TS!.log"

echo [START] 06-��ת�ź�(����) %%date%% %%time%% > "%LOG_FILE%"
call "%CONDA_ROOT%\Scripts\activate.bat" "%CONDA_ENV%" >> "%LOG_FILE%" 2>&1
pushd "%WORK_DIR%" >> "%LOG_FILE%" 2>&1

rem === �������� ===
python inc_stk_nineturn.py --init-start 20180101 --index 000905.SH --qpm 480 >> "%LOG_FILE%" 2>&1
set "ERR=!ERRORLEVEL!"

popd >> "%LOG_FILE%" 2>&1
echo [END] code=!ERR! %%date%% %%time%% >> "%LOG_FILE%"
exit /b !ERR!


# -*- coding: utf-8 -*-
"""全量下载：adj_factor（复权因子，含“前/后复权因子”计算）
- 接口：pro.adj_factor（https://tushare.pro/document/2?doc_id=28）
- 表：adj_factor（主键：ts_code_t + trade_date_t）
- 策略：按交易日逐日抓取；为得到稳定的“前复权因子”，按【交易日倒序】遍历，
        以区间“最新交易日”的因子为基准进行归一化：
          adj_factor_front_t = adj_factor_t / latest_adj_factor_per_code
        最新交易日本身的 adj_factor_front_t = 1.0
- 注意：若股票在区间末日无因子记录（如提前退市），则以“窗口内该股票最后一次出现的因子”作为归一化基准。
"""
import argparse, time
from typing import List, Dict
import pandas as pd
from sqlalchemy import text
from utils import get_engine, get_pro, log, delete_range, today_str

TABLE    = "adj_factor"
DATE_COL = "trade_date_t"

def _to_date(ymd: str) -> str:
    return f"{ymd[0:4]}-{ymd[4:6]}-{ymd[6:8]}"

def _trade_days(pro, start: str, end: str) -> List[str]:
    cal = pro.trade_cal(start_date=start, end_date=end, is_open='1')
    return cal.sort_values("cal_date")["cal_date"].tolist()

def _fetch_one_day(pro, ymd: str) -> pd.DataFrame:
    df = pro.adj_factor(trade_date=ymd, fields="ts_code,trade_date,adj_factor")
    if df is None or df.empty:
        return pd.DataFrame(columns=["ts_code","trade_date","adj_factor"])
    df = df.copy()
    df["trade_date"] = df["trade_date"].astype(str).str.slice(0,8).apply(_to_date)
    df.rename(columns={
        "ts_code":"ts_code_t",
        "trade_date":"trade_date_t",
        "adj_factor":"adj_factor_t"
    }, inplace=True)
    return df

def _compute_front_factor(df: pd.DataFrame, latest_map: Dict[str, float]) -> pd.DataFrame:
    """基于 latest_map（每个 ts_code 的“窗口内最新因子”）计算前复权因子"""
    if df.empty:
        df["adj_factor_front_t"] = []
        return df
    df = df.copy()
    denom = df["ts_code_t"].map(latest_map).fillna(df["adj_factor_t"])
    df["adj_factor_front_t"] = (df["adj_factor_t"] / denom).astype(float)
    df["adj_factor_t"] = df["adj_factor_t"].fillna(1.0)
    df["adj_factor_front_t"] = df["adj_factor_front_t"].fillna(1.0)
    return df

def _upsert(engine, df: pd.DataFrame) -> int:
    """复合主键 UPSERT；不更新主键列"""
    if df is None or df.empty:
        return 0
    cols = ["ts_code_t","trade_date_t","adj_factor_t","adj_factor_front_t"]
    for c in cols:
        if c not in df.columns:
            df[c] = None
    df = df[cols].copy()
    col_quoted   = ",".join(f"`{c}`" for c in cols)
    placeholders = ",".join(f":{c}" for c in cols)
    update_cols  = [c for c in cols if c not in ("ts_code_t","trade_date_t")]
    update_clause= ",".join(f"`{c}`=VALUES(`{c}`)" for c in update_cols)
    sql = (
        f"INSERT INTO `{TABLE}` ({col_quoted}) VALUES ({placeholders}) "
        f"ON DUPLICATE KEY UPDATE {update_clause}"
    )
    total = 0
    with engine.begin() as conn:
        for i in range(0, len(df), 1000):
            chunk = df.iloc[i:i+1000].copy()
            vals  = chunk.to_dict(orient="records")
            conn.execute(text(sql), vals)
            total += chunk.shape[0]
    return total

def main(start: str, end: str):
    pro = get_pro()
    eng = get_engine()

    # 先删区间，避免旧数据与新归一化口径不一致
    log.info(f"[full] table={TABLE} delete_range {start}~{end}")
    delete_range(eng, TABLE, DATE_COL, _to_date(start), _to_date(end))

    # 倒序处理，先遇到“窗口最新日”，作为归一化分母（每股票各自独立）
    days = _trade_days(pro, start, end)
    log.info(f"[full] table={TABLE} trade_days={len(days)}")
    latest_map: Dict[str, float] = {}

    total = 0
    for idx, ymd in enumerate(reversed(days), 1):
        raw = _fetch_one_day(pro, ymd)  # ts_code_t, trade_date_t, adj_factor_t
        if raw.empty:
            log.info(f"[full] {idx}/{len(days)} {ymd} empty")
            time.sleep(0.3); continue

        # 首次遇到即为窗口内“最新因子”（倒序）
        for code, fac in zip(raw["ts_code_t"], raw["adj_factor_t"]):
            if pd.notnull(fac) and code not in latest_map:
                latest_map[code] = float(fac)

        df = _compute_front_factor(raw, latest_map)
        n  = _upsert(eng, df)
        total += n
        log.info(f"[full] {idx}/{len(days)} {ymd} upsert rows={n} total={total}")
        time.sleep(0.3)
    log.info(f"[full] done table={TABLE} rows={total} range={start}~{end}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="19700101", help="YYYYMMDD; default=19700101")
    ap.add_argument("--end",   default=today_str(), help="YYYYMMDD; default=today")
    args = ap.parse_args()
    main(args.start.strip(), args.end.strip())

# -*- coding: utf-8 -*-
"""增量下载：每日指标 daily_basic
- 起点：库内 MAX(trade_date_t) 的下一交易日
- 终点：今天
"""
import time
from typing import List, Optional
import numpy as np
import pandas as pd
from sqlalchemy import text
from utils import get_engine, get_pro, log, get_max_date, today_str

TABLE    = "daily_basic"
DATE_COL = "trade_date_t"

FIELDS = (
    "ts_code,trade_date,close,turnover_rate,turnover_rate_f,volume_ratio,"
    "pe,pe_ttm,pb,ps,ps_ttm,dv_ratio,dv_ttm,total_share,float_share,free_share,total_mv,circ_mv"
)

def _to_date(ymd: str) -> str:
    s = str(ymd)[:8]
    return f"{s[0:4]}-{s[4:6]}-{s[6:8]}"

def _trade_days(pro, start: str, end: str) -> List[str]:
    cal = pro.trade_cal(start_date=start, end_date=end, is_open='1', fields="cal_date,is_open")
    if cal is None or cal.empty:
        return []
    return cal.sort_values("cal_date")["cal_date"].astype(str).tolist()

def _fetch_one_day(pro, ymd: str) -> pd.DataFrame:
    df = pro.daily_basic(trade_date=ymd, fields=FIELDS)
    if df is None or df.empty:
        return pd.DataFrame(columns=FIELDS.split(","))
    df = df.copy()

    df["trade_date"] = df["trade_date"].astype(str).str.slice(0,8).apply(_to_date)

    num_cols = [
        "close","turnover_rate","turnover_rate_f","volume_ratio",
        "pe","pe_ttm","pb","ps","ps_ttm","dv_ratio","dv_ttm",
        "total_share","float_share","free_share","total_mv","circ_mv"
    ]
    for c in num_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    rename_map = {
        "ts_code":"ts_code_t",
        "trade_date":"trade_date_t",
        "close":"close_t",
        "turnover_rate":"turnover_rate_t",
        "turnover_rate_f":"turnover_rate_f_t",
        "volume_ratio":"volume_ratio_t",
        "pe":"pe_t",
        "pe_ttm":"pe_ttm_t",
        "pb":"pb_t",
        "ps":"ps_t",
        "ps_ttm":"ps_ttm_t",
        "dv_ratio":"dv_ratio_t",
        "dv_ttm":"dv_ttm_t",
        "total_share":"total_share_t",
        "float_share":"float_share_t",
        "free_share":"free_share_t",
        "total_mv":"total_mv_t",
        "circ_mv":"circ_mv_t",
    }
    df.rename(columns=rename_map, inplace=True)

    cols = [
        "ts_code_t","trade_date_t","close_t",
        "turnover_rate_t","turnover_rate_f_t","volume_ratio_t",
        "pe_t","pe_ttm_t","pb_t","ps_t","ps_ttm_t",
        "dv_ratio_t","dv_ttm_t",
        "total_share_t","float_share_t","free_share_t",
        "total_mv_t","circ_mv_t",
    ]
    for c in cols:
        if c not in df.columns: df[c] = None
    return df[cols].copy()

def _upsert(engine, df: pd.DataFrame) -> int:
    if df is None or df.empty:
        return 0
    cols = [
        "ts_code_t","trade_date_t","close_t",
        "turnover_rate_t","turnover_rate_f_t","volume_ratio_t",
        "pe_t","pe_ttm_t","pb_t","ps_t","ps_ttm_t",
        "dv_ratio_t","dv_ttm_t",
        "total_share_t","float_share_t","free_share_t",
        "total_mv_t","circ_mv_t",
    ]
    df = df.copy()
    for c in cols:
        if c not in df.columns: df[c] = None
    df = df[cols]

    df = df.astype(object)
    df.replace({pd.NA: None, np.nan: None}, inplace=True)
    df.drop_duplicates(subset=["ts_code_t","trade_date_t"], keep="last", inplace=True)

    colq = ",".join(f"`{c}`" for c in cols)
    ph   = ",".join(f":{c}" for c in cols)
    upd_cols = [c for c in cols if c not in ("ts_code_t","trade_date_t")]
    upd  = ",".join(f"`{c}`=VALUES(`{c}`)" for c in upd_cols)
    sql  = f"INSERT INTO `{TABLE}` ({colq}) VALUES ({ph}) ON DUPLICATE KEY UPDATE {upd}"

    total = 0
    with engine.begin() as conn:
        for i in range(0, len(df), 2000):
            chunk = df.iloc[i:i+2000].copy()
            chunk = chunk.astype(object)
            chunk.replace({pd.NA: None, np.nan: None}, inplace=True)
            conn.execute(text(sql), chunk.to_dict(orient="records"))
            total += chunk.shape[0]
    return total

def main(start: Optional[str]=None, end: Optional[str]=None):
    pro = get_pro()
    eng = get_engine()
    if end is None:
        end = today_str()
    # 取起点：库内最大交易日的“下一交易日”
    if start is None:
        last = get_max_date(eng, TABLE, DATE_COL)  # YYYYMMDD 或 None
        start = "19900101" if last is None else last

    days = _trade_days(pro, start, end)
    if not days:
        log.info(f"[increment] table={TABLE} no trade days {start}~{end}")
        return

    # 如果 start 等于库内最后一天，把它从列表中剔除（从下一交易日开始）
    last_in_db = get_max_date(eng, TABLE, DATE_COL)
    if last_in_db and last_in_db in days:
        days = days[days.index(last_in_db)+1:]

    log.info(f"[increment] table={TABLE} trade_days={len(days)} range={start}~{end}")
    total = 0
    for i, ymd in enumerate(days, 1):
        df = _fetch_one_day(pro, ymd)
        if df is None or df.empty:
            if i % 20 == 0: log.info(f"[increment] {i}/{len(days)} {ymd} empty")
            time.sleep(0.25); continue
        n = _upsert(eng, df)
        total += n
        if n or (i % 20 == 0):
            log.info(f"[increment] {i}/{len(days)} {ymd} upsert rows={n} total={total}")
        time.sleep(0.25)
    log.info(f"[increment] done table={TABLE} rows={total} range={start}~{end}")

if __name__ == "__main__":
    main()

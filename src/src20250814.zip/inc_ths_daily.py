# -*- coding: utf-8 -*-
"""增量：同花顺板块指数日行情（ths_daily）
- 起点：库内 MAX(trade_date_t) 的下一交易日
"""
import time, numpy as np, pandas as pd
from typing import List, Optional
from sqlalchemy import text
from utils import get_engine, get_pro, log, get_max_date, today_str

TABLE="ths_daily"; PKS=("ts_code_t","trade_date_t")
FIELDS=("ts_code,trade_date,close,open,high,low,pre_close,avg_price,"
        "change,pct_change,vol,turnover_rate,total_mv,float_mv")

def _to_date(s:str)->str:
    s=str(s)[:8]; return f"{s[0:4]}-{s[4:6]}-{s[6:8]}"

def _get_ths_codes(pro):
    df=pro.ths_index(fields="ts_code")
    return [] if df is None or df.empty else df.ts_code.dropna().astype(str).tolist()

def _trade_days(pro, start, end)->List[str]:
    cal=pro.trade_cal(start_date=start, end_date=end, is_open='1', fields="cal_date")
    return [] if cal is None or cal.empty else cal.sort_values("cal_date").cal_date.astype(str).tolist()

def _fetch_one(pro, code, start, end):
    df=pro.ths_daily(ts_code=code, start_date=start, end_date=end, fields=FIELDS)
    if df is None or df.empty:
        return pd.DataFrame(columns=FIELDS.split(","))
    df=df.copy()
    df["trade_date"]=df["trade_date"].astype(str).str.slice(0,8).apply(_to_date)
    for c in ["close","open","high","low","pre_close","avg_price",
              "change","pct_change","vol","turnover_rate","total_mv","float_mv"]:
        if c in df.columns: df[c]=pd.to_numeric(df[c], errors="coerce")
    df.rename(columns={
        "ts_code":"ts_code_t","trade_date":"trade_date_t",
        "close":"close_t","open":"open_t","high":"high_t","low":"low_t",
        "pre_close":"pre_close_t","avg_price":"avg_price_t",
        "change":"change_t","pct_change":"pct_change_t","vol":"vol_t",
        "turnover_rate":"turnover_rate_t","total_mv":"total_mv_t","float_mv":"float_mv_t",
    }, inplace=True)
    cols=["ts_code_t","trade_date_t","close_t","open_t","high_t","low_t",
          "pre_close_t","avg_price_t","change_t","pct_change_t","vol_t",
          "turnover_rate_t","total_mv_t","float_mv_t"]
    for c in cols:
        if c not in df.columns: df[c]=None
    return df[cols].copy()

def _upsert(engine, df):
    if df is None or df.empty: return 0
    cols=["ts_code_t","trade_date_t","close_t","open_t","high_t","low_t",
          "pre_close_t","avg_price_t","change_t","pct_change_t","vol_t",
          "turnover_rate_t","total_mv_t","float_mv_t"]
    df=df.copy()
    for c in cols:
        if c not in df.columns: df[c]=None
    df=df[cols].astype(object).replace({pd.NA:None, np.nan:None})
    df.drop_duplicates(subset=list(PKS), keep="last", inplace=True)

    colq=",".join(f"`{c}`" for c in cols)
    ph  =",".join(f":{c}" for c in cols)
    upd =",".join(f"`{c}`=VALUES(`{c}`)" for c in cols if c not in PKS)
    sql =f"INSERT INTO `{TABLE}` ({colq}) VALUES ({ph}) ON DUPLICATE KEY UPDATE {upd}"

    n=0
    with engine.begin() as conn:
        for i in range(0,len(df),1500):
            chunk=df.iloc[i:i+1500].astype(object).replace({pd.NA:None,np.nan:None})
            conn.execute(text(sql), chunk.to_dict(orient="records"))
            n+=chunk.shape[0]
    return n

def main(start:Optional[str]=None, end:Optional[str]=None):
    pro=get_pro(); eng=get_engine()
    if end is None: end=today_str()
    if start is None:
        last=get_max_date(eng, TABLE, "trade_date_t")
        start="19900101" if last is None else last
    # 计算需要补的交易日范围（用来“下一交易日”）
    days=_trade_days(pro, start, end)
    if not days:
        log.info(f"[increment] table={TABLE} no trade days {start}~{end}"); return
    last=get_max_date(eng, TABLE, "trade_date_t")
    if last and last in days:
        days=days[days.index(last)+1:]
    if not days:
        log.info(f"[increment] table={TABLE} up-to-date"); return

    codes=_get_ths_codes(pro)
    log.info(f"[increment] table={TABLE} codes={len(codes)} trade_days={len(days)} [{days[0]}~{days[-1]}]")

    total=0
    for i,code in enumerate(codes,1):
        try:
            df=_fetch_one(pro, code, days[0], days[-1])
            total+=_upsert(eng, df)
            if i%100==0: log.info(f"[increment] {i}/{len(codes)} {code} total={total}")
            time.sleep(0.08)
        except Exception as e:
            log.exception(f"[increment] {i}/{len(codes)} {code} error: {e}")
            time.sleep(0.15)
    log.info(f"[increment] done rows={total} range={days[0]}~{days[-1]}")

if __name__=="__main__":
    main()

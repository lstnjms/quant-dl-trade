# -*- coding: utf-8 -*-
"""增量下载：adj_factor（复权因子，含“前/后复权因子”计算）"""
import time
from typing import List, Optional, Dict
import pandas as pd
from sqlalchemy import text
from utils import get_engine, get_pro, log, get_max_date, today_str

TABLE    = "adj_factor"
DATE_COL = "trade_date_t"

def _to_date(ymd: str) -> str:
    return f"{ymd[0:4]}-{ymd[4:6]}-{ymd[6:8]}"

def _trade_days(pro, start: str, end: str) -> List[str]:
    cal = pro.trade_cal(start_date=start, end_date=end, is_open='1')
    return cal.sort_values("cal_date")["cal_date"].tolist()

def _fetch_one_day(pro, ymd: str) -> pd.DataFrame:
    df = pro.adj_factor(trade_date=ymd, fields="ts_code,trade_date,adj_factor")
    if df is None or df.empty:
        return pd.DataFrame(columns=["ts_code","trade_date","adj_factor"])
    df = df.copy()
    df["trade_date"] = df["trade_date"].astype(str).str.slice(0,8).apply(_to_date)
    df.rename(columns={
        "ts_code":"ts_code_t",
        "trade_date":"trade_date_t",
        "adj_factor":"adj_factor_t"
    }, inplace=True)
    return df

def _compute_front_factor(df: pd.DataFrame, latest_map: Dict[str, float]) -> pd.DataFrame:
    if df.empty:
        df["adj_factor_front_t"] = []
        return df
    df = df.copy()
    denom = df["ts_code_t"].map(latest_map).fillna(df["adj_factor_t"])
    df["adj_factor_front_t"] = (df["adj_factor_t"] / denom).astype(float)
    df["adj_factor_t"] = df["adj_factor_t"].fillna(1.0)
    df["adj_factor_front_t"] = df["adj_factor_front_t"].fillna(1.0)
    return df

def _upsert(engine, df: pd.DataFrame) -> int:
    if df is None or df.empty:
        return 0
    cols = ["ts_code_t","trade_date_t","adj_factor_t","adj_factor_front_t"]
    for c in cols:
        if c not in df.columns:
            df[c] = None
    df = df[cols].copy()
    col_quoted   = ",".join(f"`{c}`" for c in cols)
    placeholders = ",".join(f":{c}" for c in cols)
    update_cols  = [c for c in cols if c not in ("ts_code_t","trade_date_t")]
    update_clause= ",".join(f"`{c}`=VALUES(`{c}`)" for c in update_cols)
    sql = (
        f"INSERT INTO `{TABLE}` ({col_quoted}) VALUES ({placeholders}) "
        f"ON DUPLICATE KEY UPDATE {update_clause}"
    )
    total = 0
    with engine.begin() as conn:
        for i in range(0, len(df), 1000):
            # ✅ 修正：用方括号做 iloc 切片
            chunk = df.iloc[i:i+1000].copy()
            vals  = chunk.to_dict(orient="records")
            conn.execute(text(sql), vals)
            total += chunk.shape[0]
    return total

def main(start: Optional[str]=None, end: Optional[str]=None):
    pro = get_pro()
    eng = get_engine()
    if end is None:
        end = today_str()
    if start is None:
        last = get_max_date(eng, TABLE, DATE_COL)  # 返回 YYYYMMDD 或 None
        if last is None:
            start = "19900101"
        else:
            cal = _trade_days(pro, last, end)
            if not cal:
                log.info(f"[increment] table={TABLE} already up-to-date last={last}")
                return
            if last in cal:
                idx = cal.index(last) + 1
                if idx >= len(cal):
                    log.info(f"[increment] table={TABLE} already up-to-date last={last}")
                    return
                start = cal[idx]
            else:
                start = cal[0]

    days = _trade_days(pro, start, end)
    log.info(f"[increment] table={TABLE} range={start}~{end} trade_days={len(days)}")
    latest_map: Dict[str, float] = {}
    total = 0
    for i, ymd in enumerate(reversed(days), 1):
        raw = _fetch_one_day(pro, ymd)
        if raw.empty:
            log.info(f"[increment] {i}/{len(days)} {ymd} empty")
            time.sleep(0.3); continue

        for code, fac in zip(raw["ts_code_t"], raw["adj_factor_t"]):
            if pd.notnull(fac) and code not in latest_map:
                latest_map[code] = float(fac)

        df = _compute_front_factor(raw, latest_map)
        n  = _upsert(eng, df)
        total += n
        log.info(f"[increment] {i}/{len(days)} {ymd} upsert rows={n} total={total}")
        time.sleep(0.3)
    log.info(f"[increment] done table={TABLE} rows={total} range={start}~{end}")

if __name__ == "__main__":
    main()

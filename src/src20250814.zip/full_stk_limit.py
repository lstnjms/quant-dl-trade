# -*- coding: utf-8 -*-
"""全量下载：每日涨跌停价格（stk_limit）
- 接口：pro.stk_limit
- 粒度：逐交易日拉取
- 规范：先删区间再重下；*_t 映射；UPSERT 幂等；NaN/NA→None
"""
import argparse, time
from typing import List
import numpy as np
import pandas as pd
from sqlalchemy import text
from utils import get_engine, get_pro, log, delete_range, today_str

TABLE    = "stk_limit"
DATE_COL = "trade_date_t"
FIELDS   = "ts_code,trade_date,pre_close,up_limit,down_limit"

def _to_date(ymd: str) -> str:
    s = str(ymd)[:8]
    return f"{s[0:4]}-{s[4:6]}-{s[6:8]}"

def _trade_days(pro, start: str, end: str) -> List[str]:
    cal = pro.trade_cal(start_date=start, end_date=end, is_open='1', fields="cal_date,is_open")
    if cal is None or cal.empty: return []
    return cal.sort_values("cal_date")["cal_date"].astype(str).tolist()

def _fetch_one_day(pro, ymd: str) -> pd.DataFrame:
    df = pro.stk_limit(trade_date=ymd, fields=FIELDS)
    if df is None or df.empty:
        return pd.DataFrame(columns=FIELDS.split(","))
    df = df.copy()
    df["trade_date"] = df["trade_date"].astype(str).str.slice(0,8).apply(_to_date)
    for c in ["pre_close","up_limit","down_limit"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df.rename(columns={
        "ts_code":"ts_code_t",
        "trade_date":"trade_date_t",
        "pre_close":"pre_close_t",
        "up_limit":"up_limit_t",
        "down_limit":"down_limit_t",
    }, inplace=True)
    cols = ["ts_code_t","trade_date_t","pre_close_t","up_limit_t","down_limit_t"]
    for c in cols:
        if c not in df.columns: df[c] = None
    return df[cols].copy()

def _upsert(engine, df: pd.DataFrame) -> int:
    if df is None or df.empty: return 0
    cols = ["ts_code_t","trade_date_t","pre_close_t","up_limit_t","down_limit_t"]
    df = df.copy()
    for c in cols:
        if c not in df.columns: df[c] = None
    df = df[cols]

    # 去 NaN/NA，防 PyMySQL nan 错
    df = df.astype(object)
    df.replace({pd.NA: None, np.nan: None}, inplace=True)
    df.drop_duplicates(subset=["ts_code_t","trade_date_t"], keep="last", inplace=True)

    colq = ",".join(f"`{c}`" for c in cols)
    ph   = ",".join(f":{c}" for c in cols)
    upd  = ",".join(f"`{c}`=VALUES(`{c}`)" for c in cols if c not in ("ts_code_t","trade_date_t"))
    sql  = f"INSERT INTO `{TABLE}` ({colq}) VALUES ({ph}) ON DUPLICATE KEY UPDATE {upd}"

    total = 0
    with engine.begin() as conn:
        for i in range(0, len(df), 2000):
            chunk = df.iloc[i:i+2000].copy()
            chunk = chunk.astype(object).replace({pd.NA: None, np.nan: None})
            conn.execute(text(sql), chunk.to_dict(orient="records"))
            total += chunk.shape[0]
    return total

def main(start: str, end: str):
    pro = get_pro()
    eng = get_engine()

    days = _trade_days(pro, start, end)
    if not days:
        log.info(f"[full] table={TABLE} no trade days {start}~{end}")
        return

    # 先按日期清区间
    delete_range(eng, TABLE, DATE_COL, _to_date(days[0]), _to_date(days[-1]))

    total = 0
    for i, ymd in enumerate(days, 1):
        try:
            df = _fetch_one_day(pro, ymd)
            if df.empty:
                if i % 20 == 0: log.info(f"[full] {i}/{len(days)} {ymd} empty")
                time.sleep(0.15); continue
            n = _upsert(eng, df)
            total += n
            if n or (i % 20 == 0):
                log.info(f"[full] {i}/{len(days)} {ymd} rows={n} total={total}")
            time.sleep(0.15)
        except Exception as e:
            log.exception(f"[full] {i}/{len(days)} {ymd} error: {e}")
            time.sleep(0.3)

    log.info(f"[full] done table={TABLE} rows={total} range={start}~{end}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="19900101", help="YYYYMMDD; default=19900101")
    ap.add_argument("--end",   default=today_str(), help="YYYYMMDD; default=today")
    args = ap.parse_args()
    main(args.start.strip(), args.end.strip())

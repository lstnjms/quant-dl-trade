# -*- coding: utf-8 -*-
"""全量下载：每日指标 daily_basic（逐交易日）
- 接口：pro.daily_basic (doc_id=32)
- 表：daily_basic（主键：ts_code_t + trade_date_t）
- 规范：先删区间再重下；*_t 映射；UPSERT 幂等；NaN/NA → None
"""
import argparse, time
from typing import List
import numpy as np
import pandas as pd
from sqlalchemy import text
from utils import get_engine, get_pro, log, delete_range, today_str

TABLE    = "daily_basic"
DATE_COL = "trade_date_t"

# 尽量一次把常用字段要齐；缺失字段会在下游补 None
FIELDS = (
    "ts_code,trade_date,close,turnover_rate,turnover_rate_f,volume_ratio,"
    "pe,pe_ttm,pb,ps,ps_ttm,dv_ratio,dv_ttm,total_share,float_share,free_share,total_mv,circ_mv"
)

def _to_date(ymd: str) -> str:
    s = str(ymd)[:8]
    return f"{s[0:4]}-{s[4:6]}-{s[6:8]}"

def _trade_days(pro, start: str, end: str) -> List[str]:
    cal = pro.trade_cal(start_date=start, end_date=end, is_open='1', fields="cal_date,is_open")
    if cal is None or cal.empty:
        return []
    return cal.sort_values("cal_date")["cal_date"].astype(str).tolist()

def _fetch_one_day(pro, ymd: str) -> pd.DataFrame:
    df = pro.daily_basic(trade_date=ymd, fields=FIELDS)
    if df is None or df.empty:
        return pd.DataFrame(columns=FIELDS.split(","))
    df = df.copy()

    # 日期
    df["trade_date"] = df["trade_date"].astype(str).str.slice(0,8).apply(_to_date)

    # 数值规范化
    num_cols = [
        "close","turnover_rate","turnover_rate_f","volume_ratio",
        "pe","pe_ttm","pb","ps","ps_ttm","dv_ratio","dv_ttm",
        "total_share","float_share","free_share","total_mv","circ_mv"
    ]
    for c in num_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    # 改名为 *_t
    rename_map = {
        "ts_code":"ts_code_t",
        "trade_date":"trade_date_t",
        "close":"close_t",
        "turnover_rate":"turnover_rate_t",
        "turnover_rate_f":"turnover_rate_f_t",
        "volume_ratio":"volume_ratio_t",
        "pe":"pe_t",
        "pe_ttm":"pe_ttm_t",
        "pb":"pb_t",
        "ps":"ps_t",
        "ps_ttm":"ps_ttm_t",
        "dv_ratio":"dv_ratio_t",
        "dv_ttm":"dv_ttm_t",
        "total_share":"total_share_t",
        "float_share":"float_share_t",
        "free_share":"free_share_t",
        "total_mv":"total_mv_t",
        "circ_mv":"circ_mv_t",
    }
    df.rename(columns=rename_map, inplace=True)

    cols = [
        "ts_code_t","trade_date_t","close_t",
        "turnover_rate_t","turnover_rate_f_t","volume_ratio_t",
        "pe_t","pe_ttm_t","pb_t","ps_t","ps_ttm_t",
        "dv_ratio_t","dv_ttm_t",
        "total_share_t","float_share_t","free_share_t",
        "total_mv_t","circ_mv_t",
    ]
    for c in cols:
        if c not in df.columns: df[c] = None
    return df[cols].copy()

def _upsert(engine, df: pd.DataFrame) -> int:
    if df is None or df.empty:
        return 0
    cols = [
        "ts_code_t","trade_date_t","close_t",
        "turnover_rate_t","turnover_rate_f_t","volume_ratio_t",
        "pe_t","pe_ttm_t","pb_t","ps_t","ps_ttm_t",
        "dv_ratio_t","dv_ttm_t",
        "total_share_t","float_share_t","free_share_t",
        "total_mv_t","circ_mv_t",
    ]
    df = df.copy()
    for c in cols:
        if c not in df.columns: df[c] = None
    df = df[cols]

    # 统一去 NaN/NA，避免 PyMySQL 报错（float('nan')）
    df = df.astype(object)
    df.replace({pd.NA: None, np.nan: None}, inplace=True)
    df.drop_duplicates(subset=["ts_code_t","trade_date_t"], keep="last", inplace=True)

    colq = ",".join(f"`{c}`" for c in cols)
    ph   = ",".join(f":{c}" for c in cols)
    upd_cols = [c for c in cols if c not in ("ts_code_t","trade_date_t")]
    upd  = ",".join(f"`{c}`=VALUES(`{c}`)" for c in upd_cols)
    sql  = f"INSERT INTO `{TABLE}` ({colq}) VALUES ({ph}) ON DUPLICATE KEY UPDATE {upd}"

    total = 0
    with engine.begin() as conn:
        for i in range(0, len(df), 2000):
            chunk = df.iloc[i:i+2000].copy()
            chunk = chunk.astype(object)
            chunk.replace({pd.NA: None, np.nan: None}, inplace=True)
            conn.execute(text(sql), chunk.to_dict(orient="records"))
            total += chunk.shape[0]
    return total

def main(start: str, end: str):
    pro = get_pro()
    eng = get_engine()

    days = _trade_days(pro, start, end)
    if not days:
        log.info(f"[full] table={TABLE} no trade days {start}~{end}")
        return

    # 先删区间（按交易日）
    delete_range(eng, TABLE, DATE_COL, _to_date(days[0]), _to_date(days[-1]))

    total = 0
    for i, ymd in enumerate(days, 1):
        df = _fetch_one_day(pro, ymd)
        if df is None or df.empty:
            if i % 20 == 0: log.info(f"[full] {i}/{len(days)} {ymd} empty")
            time.sleep(0.25); continue
        n = _upsert(eng, df)
        total += n
        if n or (i % 20 == 0):
            log.info(f"[full] {i}/{len(days)} {ymd} upsert rows={n} total={total}")
        time.sleep(0.25)
    log.info(f"[full] done table={TABLE} rows={total} range={start}~{end}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="19900101", help="YYYYMMDD; default=19900101")
    ap.add_argument("--end",   default=today_str(), help="YYYYMMDD; default=today")
    args = ap.parse_args()
    main(args.start.strip(), args.end.strip())

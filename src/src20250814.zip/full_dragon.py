# -*- coding: utf-8 -*-
"""全量下载：龙虎榜每日明细（席位买卖 + 上榜原因）
- 买卖数据：pro.top_inst
- 原因：pro.top_list
- 粒度：逐交易日；主键（唯一约束）：ts_code_t + trade_date_t + exalter_t
"""
import argparse, time
from typing import List
import numpy as np
import pandas as pd
from sqlalchemy import text
from utils import get_engine, get_pro, log, delete_range, today_str

TABLE    = "dragon_t"
DATE_COL = "trade_date_t"

FIELDS_INST = "trade_date,ts_code,exalter,buy,sell,net_buy"
FIELDS_LIST = "trade_date,ts_code,reason"

def _to_date(ymd: str) -> str:
    s = str(ymd)[:8]
    return f"{s[0:4]}-{s[4:6]}-{s[6:8]}"

def _trade_days(pro, start: str, end: str) -> List[str]:
    cal = pro.trade_cal(start_date=start, end_date=end, is_open='1', fields="cal_date,is_open")
    if cal is None or cal.empty:
        return []
    return cal.sort_values("cal_date")["cal_date"].astype(str).tolist()

def _fetch_one_day(pro, ymd: str) -> pd.DataFrame:
    # 机构/营业部成交金额（席位）
    inst = pro.top_inst(trade_date=ymd, fields=FIELDS_INST)
    if inst is None or inst.empty:
        inst = pd.DataFrame(columns=["trade_date","ts_code","exalter","buy","sell","net_buy"])
    else:
        inst = inst.copy()
    # 上榜原因（按股票日）
    tlst = pro.top_list(trade_date=ymd, fields=FIELDS_LIST)
    if tlst is None or tlst.empty:
        tlst = pd.DataFrame(columns=["trade_date","ts_code","reason"])
    else:
        tlst = tlst.copy()
        # 同一股票当日可能有多条，取第一条原因（足够用）
        tlst = tlst.sort_values("ts_code").drop_duplicates(["trade_date","ts_code"], keep="first")

    if inst.empty and tlst.empty:
        return pd.DataFrame(columns=[
            "ts_code_t","trade_date_t","exalter_t","buy_amount_t","sell_amount_t","net_amount_t","reason_t"
        ])

    # 合并 reason
    m = pd.merge(
        inst, tlst[["trade_date","ts_code","reason"]],
        on=["trade_date","ts_code"], how="left"
    )

    # 规范化为 *_t
    m["trade_date"] = m["trade_date"].astype(str).str.slice(0,8).apply(_to_date)
    for col in ["buy","sell","net_buy"]:
        m[col] = pd.to_numeric(m[col], errors="coerce")
    # 金额缺失按表结构要求置 0.0
    m["buy"]     = m["buy"].fillna(0.0)
    m["sell"]    = m["sell"].fillna(0.0)
    m["net_buy"] = m["net_buy"].fillna(0.0)
    # 去掉没有席位名的行（无法构成唯一键）
    if "exalter" in m.columns:
        m = m[m["exalter"].notna() & (m["exalter"].astype(str).str.strip()!="")]

    m.rename(columns={
        "ts_code":"ts_code_t",
        "trade_date":"trade_date_t",
        "exalter":"exalter_t",
        "buy":"buy_amount_t",
        "sell":"sell_amount_t",
        "net_buy":"net_amount_t",
        "reason":"reason_t",
    }, inplace=True)

    cols = ["ts_code_t","trade_date_t","exalter_t","buy_amount_t","sell_amount_t","net_amount_t","reason_t"]
    for c in cols:
        if c not in m.columns: m[c] = None
    m = m[cols].copy()
    return m

def _upsert(engine, df: pd.DataFrame) -> int:
    if df is None or df.empty:
        return 0
    cols = ["ts_code_t","trade_date_t","exalter_t","buy_amount_t","sell_amount_t","net_amount_t","reason_t"]
    df = df.copy()
    for c in cols:
        if c not in df.columns:
            df[c] = None
    df = df[cols]

    # 金额列保证非空（NOT NULL）
    for c in ["buy_amount_t","sell_amount_t","net_amount_t"]:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)

    # 彻底清除 NaN → None（其余允许 NULL）
    df = df.astype(object)
    df.replace({pd.NA: None, np.nan: None}, inplace=True)
    # 防重复（同一日/股/席位）
    df.drop_duplicates(subset=["ts_code_t","trade_date_t","exalter_t"], keep="last", inplace=True)

    colq = ",".join(f"`{c}`" for c in cols)
    ph   = ",".join(f":{c}" for c in cols)
    upd_cols = [c for c in cols if c not in ("ts_code_t","trade_date_t","exalter_t")]
    upd  = ",".join(f"`{c}`=VALUES(`{c}`)" for c in upd_cols)
    sql  = f"INSERT INTO `{TABLE}` ({colq}) VALUES ({ph}) ON DUPLICATE KEY UPDATE {upd}"

    total = 0
    with engine.begin() as conn:
        for i in range(0, len(df), 1000):
            chunk = df.iloc[i:i+1000].copy()
            chunk = chunk.astype(object)
            chunk.replace({pd.NA: None, np.nan: None}, inplace=True)
            conn.execute(text(sql), chunk.to_dict(orient="records"))
            total += chunk.shape[0]
    return total

def main(start: str, end: str):
    pro = get_pro()
    eng = get_engine()

    days = _trade_days(pro, start, end)
    if not days:
        log.info(f"[full] table={TABLE} no trade days {start}~{end}")
        return

    # 按交易日清区间
    delete_range(eng, TABLE, DATE_COL, _to_date(days[0]), _to_date(days[-1]))

    total = 0
    for i, ymd in enumerate(days, 1):
        df = _fetch_one_day(pro, ymd)
        if df is None or df.empty:
            if i % 20 == 0:
                log.info(f"[full] {i}/{len(days)} {ymd} empty")
            time.sleep(0.25); continue
        n = _upsert(eng, df)
        total += n
        if n or (i % 20 == 0):
            log.info(f"[full] {i}/{len(days)} {ymd} upsert rows={n} total={total}")
        time.sleep(0.25)
    log.info(f"[full] done table={TABLE} rows={total} range={start}~{end}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="19900101", help="YYYYMMDD; default=19900101")
    ap.add_argument("--end",   default=today_str(), help="YYYYMMDD; default=today")
    args = ap.parse_args()
    main(args.start.strip(), args.end.strip())

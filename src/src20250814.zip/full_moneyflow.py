# -*- coding: utf-8 -*-
"""全量下载：moneyflow（资金流向，逐交易日抓取全市场）
- 接口：pro.moneyflow（https://tushare.pro/document/2?doc_id=170）
- 表：moneyflow（主键：ts_code_t + trade_date_t）
- 策略：按交易日逐日抓取；区间内先 DELETE 再重下；复合主键 UPSERT。
"""
import argparse, time
from typing import List
import pandas as pd
from sqlalchemy import text
from utils import get_engine, get_pro, log, delete_range, today_str

TABLE    = "moneyflow"
DATE_COL = "trade_date_t"

# 为兼容不同账户字段权限，这里只列出你表结构需要的字段
FIELDS = (
    "ts_code,trade_date,"
    "buy_sm_vol,buy_sm_amount,sell_sm_vol,sell_sm_amount,"
    "buy_md_vol,buy_md_amount,sell_md_vol,sell_md_amount,"
    "buy_lg_vol,buy_lg_amount,sell_lg_vol,sell_lg_amount,"
    "buy_elg_vol,buy_elg_amount,sell_elg_vol,sell_elg_amount,"
    "net_mf_amount"
)

NEED_COLS_SRC = [
    "ts_code","trade_date",
    "buy_sm_vol","buy_sm_amount","sell_sm_vol","sell_sm_amount",
    "buy_md_vol","buy_md_amount","sell_md_vol","sell_md_amount",
    "buy_lg_vol","buy_lg_amount","sell_lg_vol","sell_lg_amount",
    "buy_elg_vol","buy_elg_amount","sell_elg_vol","sell_elg_amount",
    "net_mf_amount"
]

NEED_COLS_DST = [
    "ts_code_t","trade_date_t",
    "buy_sm_vol_t","buy_sm_amount_t","sell_sm_vol_t","sell_sm_amount_t",
    "buy_md_vol_t","buy_md_amount_t","sell_md_vol_t","sell_md_amount_t",
    "buy_lg_vol_t","buy_lg_amount_t","sell_lg_vol_t","sell_lg_amount_t",
    "buy_elg_vol_t","buy_elg_amount_t","sell_elg_vol_t","sell_elg_amount_t",
    "net_mf_amount_t"
]

def _to_date(ymd: str) -> str:
    return f"{ymd[0:4]}-{ymd[4:6]}-{ymd[6:8]}"

def _trade_days(pro, start: str, end: str) -> List[str]:
    cal = pro.trade_cal(start_date=start, end_date=end, is_open='1')
    return cal.sort_values("cal_date")["cal_date"].tolist()

def _fetch_one_day(pro, ymd: str) -> pd.DataFrame:
    df = pro.moneyflow(trade_date=ymd, fields=FIELDS)
    if df is None or df.empty:
        return pd.DataFrame(columns=NEED_COLS_SRC)
    # 只取需要列，缺的先补空
    for c in NEED_COLS_SRC:
        if c not in df.columns:
            df[c] = None
    df = df[NEED_COLS_SRC].copy()
    # 映射并格式化日期
    df["trade_date"] = df["trade_date"].astype(str).str.slice(0,8).apply(_to_date)
    df.rename(columns={
        "ts_code":"ts_code_t",
        "trade_date":"trade_date_t",
        "buy_sm_vol":"buy_sm_vol_t",
        "buy_sm_amount":"buy_sm_amount_t",
        "sell_sm_vol":"sell_sm_vol_t",
        "sell_sm_amount":"sell_sm_amount_t",
        "buy_md_vol":"buy_md_vol_t",
        "buy_md_amount":"buy_md_amount_t",
        "sell_md_vol":"sell_md_vol_t",
        "sell_md_amount":"sell_md_amount_t",
        "buy_lg_vol":"buy_lg_vol_t",
        "buy_lg_amount":"buy_lg_amount_t",
        "sell_lg_vol":"sell_lg_vol_t",
        "sell_lg_amount":"sell_lg_amount_t",
        "buy_elg_vol":"buy_elg_vol_t",
        "buy_elg_amount":"buy_elg_amount_t",
        "sell_elg_vol":"sell_elg_vol_t",
        "sell_elg_amount":"sell_elg_amount_t",
        "net_mf_amount":"net_mf_amount_t",
    }, inplace=True)
    return df

def _upsert(engine, df: pd.DataFrame) -> int:
    """复合主键 UPSERT；不更新主键列"""
    if df is None or df.empty:
        return 0
    cols = NEED_COLS_DST
    for c in cols:
        if c not in df.columns:
            df[c] = None
    df = df[cols].copy()
    col_quoted   = ",".join(f"`{c}`" for c in cols)
    placeholders = ",".join(f":{c}" for c in cols)
    update_cols  = [c for c in cols if c not in ("ts_code_t","trade_date_t")]
    update_clause= ",".join(f"`{c}`=VALUES(`{c}`)" for c in update_cols)
    sql = (
        f"INSERT INTO `{TABLE}` ({col_quoted}) VALUES ({placeholders}) "
        f"ON DUPLICATE KEY UPDATE {update_clause}"
    )
    total = 0
    with engine.begin() as conn:
        for i in range(0, len(df), 1000):
            chunk = df.iloc[i:i+1000].copy()
            vals  = chunk.to_dict(orient="records")
            conn.execute(text(sql), vals)
            total += chunk.shape[0]
    return total

def main(start: str, end: str):
    pro = get_pro()
    eng = get_engine()

    log.info(f"[full] table={TABLE} delete_range {start}~{end}")
    delete_range(eng, TABLE, DATE_COL, _to_date(start), _to_date(end))

    days = _trade_days(pro, start, end)
    log.info(f"[full] table={TABLE} trade_days={len(days)}")
    total = 0
    for i, ymd in enumerate(days, 1):
        df = _fetch_one_day(pro, ymd)
        if df is None or df.empty:
            log.info(f"[full] {i}/{len(days)} {ymd} empty")
            time.sleep(0.35); continue
        n = _upsert(eng, df)
        total += n
        log.info(f"[full] {i}/{len(days)} {ymd} upsert rows={n} total={total}")
        time.sleep(0.35)
    log.info(f"[full] done table={TABLE} rows={total} range={start}~{end}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="19700101", help="YYYYMMDD; default=19700101")
    ap.add_argument("--end",   default=today_str(), help="YYYYMMDD; default=today")
    args = ap.parse_args()
    main(args.start.strip(), args.end.strip())
